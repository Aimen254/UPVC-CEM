{{ Form::model($milestone, array('route' => array('project.window.update', $milestone->id), 'method' => 'POST')) }}
<div class="modal-body">
<div class="row">
        <div class="col-12 form-group">
            <label><strong>Width</strong></label><br/>
            <input class="form-control" type="number" name="width" id="width">
        </div>
        <div class="col-12 form-group">
                <label><strong>Height</strong></label><br/>
                <input class="form-control" type="number" name="height" id="height">
        </div>
        <div class="col-md-6">
            <div class="form-check form-check-inline">
                <input type="radio" class="form-check-input" id="customRadio5" name="type" value="gear_handles" checked="checked" onclick="hide_show(this)">
                <label class="custom-control-label form-label" for="customRadio5">{{__('Gear Handles')}}</label>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-check form-check-inline">
                <input type="radio" class="form-check-input" id="customRadio6" name="type" value="interlock" onclick="hide_show(this)">
                <label class="custom-control-label form-label" for="customRadio6">{{__('Interlock')}}</label>
            </div>
        </div>
</div>
</div>
<div class="modal-footer">
    <input type="button" value="{{__('Cancel')}}" class="btn  btn-light" data-bs-dismiss="modal">
    <input class="btn btn-sm btn-primary btn-icon rounded-pill" type="submit" value="Add">
</div>
{{ Form::close() }}