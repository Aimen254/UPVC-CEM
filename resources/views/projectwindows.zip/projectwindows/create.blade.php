{{ Form::open(['route' => ['project.window.store' ,$project->id],'enctype' => 'multipart/form-data']) }}
<div class="modal-body">
    <div class="row">
      
        <div class="col-12 form-group">
            {{ Form::label('frame_id', __('Select Frames'),['class'=>'form-label']) }}<span class="text-danger">*</span>
            {{ Form::select('frame_id', $access,null, array('class' => 'form-control select','required'=>'required')) }}
        </div>
        <div class="col-12 form-group">
                {{ Form::label('quantity', __('Quantity'), ['class' => 'form-label']) }}
                {{ Form::number('quantity', null, ['class' => 'form-control']) }}
        </div>
    </div>
</div>

<div class="modal-footer">
    <input type="button" value="{{__('Cancel')}}" class="btn  btn-light" data-bs-dismiss="modal">
    <input type="submit" value="{{__('Create')}}" class="btn  btn-primary">
</div>

{{Form::close()}}

